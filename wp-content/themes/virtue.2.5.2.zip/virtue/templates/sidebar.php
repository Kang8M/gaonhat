<?php	
dynamic_sidebar( kadence_sidebar_id() );