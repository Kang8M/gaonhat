	
 Thank you for purchasing Virtue Premium Theme!

-------------------------------------------------------
    Virtue Theme Licensing:
-------------------------------------------------------

Virtue Theme itself is licensed under the General Public License V3

However the following premium plugins that are bundled with virtue are not licensed under the theme but have their own license. 
These plugins have been purchased for the use in the Virtue Theme only. Refer to each license in the plugin files.
- The Revolution Slider (Licensed URL: http://codecanyon.net/licenses/regular) This slider can only be used on one domain per purchase of a theme. For more domains you can purchase another single site license here: http://codecanyon.net/item/slider-revolution-responsive-wordpress-plugin/
- The Cylcone Slider 
- Isotope Jquery Plugin


-------------------------------------------------------
    Credits:
-------------------------------------------------------
Virtue Theme Uses:

* Photos on example_slider by Benjamin Ritner (licensed under GNU General Public License v2.0 or later)
* Icon Font & Icon images by Icomoon (Used with permission under purchased developer licenses:  http://icomoon.io/#icons/license)
* FlexSlider by WooThemes under the GPLv2 license (http://www.gnu.org/licenses/gpl-2.0.html)
* Redux Options Framework (http://reduxframework.com/) licensed under GNU General Public License v3.0
* Google Fonts (available through Google web Fonts: http://www.google.com/fonts/), licensed under Apache License Version 2
* Aqua Resizer (https://github.com/syamilmj/Aqua-Resizer), licensed under WTFPL http://www.wtfpl.net/
* Twitter Bootstrap (https://github.com/twbs/bootstrap), licensed under Apache License Version 2
* Custom Metaboxes and Fields for Wordpress (https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress), licensed under GNU General Public License v2.0 or later
* Magnific Popup (http://dimsemenov.com/plugins/magnific-popup/) licensed under MIT license, http://www.opensource.org/licenses/mit-license.php
* carouFredSel (https://github.com/gilbitron/carouFredSel), licensed under GNU General Public License v2.0 or later 
* Select2 (http://ivaynberg.github.io/select2/), licensed under GNU General Public License v2.0 or later
* hoverIntent (https://github.com/briancherne/jquery-hoverIntent), licensed under MIT license, http://www.opensource.org/licenses/mit-license.php
* Superfish (https://github.com/joeldbirch/superfish) Dual licensed under the MIT and GPL licenses: http://www.opensource.org/licenses/mit-license.php, http://www.gnu.org/licenses/gpl.html
* MobileDetect (http://mobiledetect.net/) licensed under MIT license, http://www.opensource.org/licenses/mit-license.php
* Fitvids (https://github.com/davatron5000/FitVids.js/blob/master/jquery.fitvids.js), Released under the WTFPL license - http://sam.zoy.org/wtfpl/
* touchSwipe, (https://github.com/mattbryson/TouchSwipe-Jquery-Plugin), Dual licensed under the MIT or GPL Version 2 licenses
* Infinitescroll, (https://github.com/paulirish/infinite-scroll), licensed under GNU General Public License v2.0 or later
* jquery.customSelect (http://adam.co/lab/jquery/customselect/), Dual licensed under the MIT or GPL Version 2 licenses
* GMAP3 Plugin for JQuery (http://gmap3.net/), licensed under GNU General Public License v3.0
* jQuery Scroll to Top Control script (http://www.dynamicdrive.com/) Custom license: http://www.dynamicdrive.com/notice.htm
* TGM Plugin Activation library (https://github.com/thomasgriffin/TGM-Plugin-Activation) licensed under GNU General Public License v2.0 or later
* RootsTheme (http://www.rootstheme.com/) licensed under MIT license, http://www.opensource.org/licenses/mit-license.php
* Nice Scroll (https://github.com/inuyaksa/jquery.nicescroll) licensed under MIT license, http://www.opensource.org/licenses/mit-license.php
* Cylone Slider Pro (http://www.codefleet.net/cyclone-slider-pro/) 
* Revolution Slider (http://www.themepunch.com/codecanyon/revolution_wp/) Licensed URL: http://codecanyon.net/licenses/regular 
* Isotope (http://isotope.metafizzy.co/)
* SmartResize (https://github.com/louisremi/jquery-smartresize) licensed under MIT license, http://www.opensource.org/licenses/mit-license.php

-------------------------------------------------------
    Changelog:
-------------------------------------------------------

= Theme Name: Virtue Premium =

= Version 2.7.8 =
* Hot Fix

= Version 2.7.7 =
* Fix smoothscroll IE10 & 11
* Update parallax scroll
* Fix customizer
* Add option for default captions in galleries

= Version 2.7.6 =
* Update for new pagebuilder
* Update gallery shortcode

= Version 2.7.5 =
* Add option for comments on a page.
* Add option to set portfolio item count on type pages.
* Add blog_grid shortcode
* Small CSS fix for firefox.
* Updated in prep of woocommerce 2.3

= Version 2.7.4 =
* Small Fix

= Version 2.7.3 =
* Fix for filters when two isotope items on a page.
* Add portfolio randomizer for flex slider init.
* Fix global var for accordion.
* Fix select box issue on mobile.
* Add shortcode for portfolio types

= Version 2.7.2 =
* Gallery Lightbox size options.
* Gallery image size override.
* Gallery in tab issues.
* Mobile Slider issue.
* Update theme options.
* Add image meta size to the portfolio carousel image tag.

= Version 2.7.1 =
* Again readmore for fullposts blog page.

= Version 2.7.0 =
* Readmore for fullposts blog page.

= Version 2.6.9 =
* Parallax css fix for ipad.
* Add soundcloud and yelp social icons
* Update Kadence Slider

= Version 2.6.8 =
* Small css fix.
* Feature image update.
* Update revslider, Kadence slider

= Version 2.6.7 =
* Small css fix.
* Fix for latest update of visual editor widget.

= Version 2.6.6 =
* Small css fix.

= Version 2.6.5 =
* Small css fix.
* Add id for tabs.
* Add my account link.
* Add staff lightbox and staff single sidebar options.
* Fix missing fn class.
* Add hover option to button shortcode.
* Update for visual editor update.

= Version 2.6.4 =
* Update Theme Options
* Add id option for icon box.
* Update product carousel order

= Version 2.6.3 =
* Support WooCommerce German Market
* Add better math question for contact form.
* Add string translation for shortcode slider box

= Version 2.6.2 =
* Add order to portfolio shortcode.
* Update for events plugin.
* Add option to make category pages grid format.
* Update Theme options
* Remove old update path for versions pre 1.7.3 (speed up theme options).
* Recent posts update.
* Update language file.

= Version 2.6.1 =
* Remove the percentage.
* Update language files.

= Version 2.6.0 =
* Woocommerce 2.2.0 support.
* Pagbuilder tweek.
* Similar post update.

= Version 2.5.9 =
* Update pagebuilder output code.
* Update WPML Widget Support.
* Update theme options.
* Randomize similar posts option.
* Add select support for Composite Products woocommerce extension.

= Version 2.5.8 =
* Update blog shortcode.
* Added Staff Filter
* Small undefined variable fix.
* Update Theme Options, google font fix.
* Added Black Studio TinyMCE Widget as recommended
* Add Page builder wide content style
* Add kad_box shortcode
* New Portfolio category page template. 
* Fixed Smooth Scroll issue.
* Fix for visual widget
* Add option for single testimonial post navigation
* Added option for staff grid to link to single post page.
* Added xing to social widget.

= Version 2.5.7 =
* More WPML Support.
* Fixed Smooth scroll Issue
* Small Portfolio shortcode fix.
* Fix testimonial carousel.
* Image size issue.

= Version 2.5.6 =
* Small variable fix 

= Version 2.5.5 =
* New fullwidth submenu option.
* New option for full posts in categories.
* Allow sale carousel to be limited to category.
* Fix Author Default Settings.
* Fix Category Full width settings.
* Update comment form for better filters use.

= Version 2.5.4 =
* Clean up Shortcodes script.
* Reformat gmaps for wootabs.
* Update Js for carousel resize.

= Version 2.5.3 =
* Portfolio Grid password protect support.
* Add filter option to portfolio shortcode.
* Add new blog shortcode option.
* Add fixed phone to vcard widget.
* Fix woocommerce template.
* Small fix with home page title.

= Version 2.5.2 =
* Small Update, just updating copy of revolution slider.

= Version 2.5.1 =
* Fix - Some Users reporting issue with theme options.

= Version 2.5.0 =
* Users reporting issue with theme options.
* Move theme options to avoid conflict with sensei.

= Version 2.4.9 =
* Force icons to load, some users reporting icons missing.
* Small fix for google fonts.
* Allow image widget caption to have html.

= Version 2.4.8 =
* Small Fix for blog posts

= Version 2.4.7 =
* Remove text align options in typography settings
* Update theme options
* Add support of product finder
* Add basic sensei support
* Add target="_blank" option to button shortcode
* Add menu id class
* Make the home page title appear above the sidebar
* Add class for topbar icon menu items
* Update carousel widget, now choose category
* Add a few icons to virtue icon font
* Update Carousel shortcode
* Update language files
* Add image option to front end testimonial posting shortcode
* Update revolution slider

= Version 2.4.6 =
* Add front end testimonial posting shortcode.
* Add single column option for testimonial post.
* Add option in testimonial carousel to link to testimonial grid page.
* Add option in info box to give text a color

= Version 2.4.5 =
* Fix small issue slides not deleting.
* Fix skins not showing.

= Version 2.4.4 =
* Fix small issue with the checkboxes in the portfolio meta.

= Version 2.4.3 =
* Update theme options panel, huge speed improvement.
* Updated Sticky header with slider above.
* Add my account sidebar with image.
* Small typo fix & clean up files.
* Update Language files and added partial Dutch
* Small fix for parallax in chrome browser.

= Version 2.4.2 =
* Fix Breadcrumb text domain issue.
* Add Image menu Item widget.
* Add Carousel slider to feature template.
* Update Sticky header JS
* Update Language files
* Updated Latest Post from Author

= Version 2.4.1 =
* Fix Home Carousel Slider Issue
* Fix CSS issue with portfolio slider images 

= Version 2.4.0 =
* Add new Kadence Slider
* Add option to turn select boxes off
* Add link option to infobox widget and shortcode
* Add option for slider above header on feature pages
* Add option shortcode for modals
* Fix small mqtranlslate issue with contact form
* Fix small issue with the blog shortcode.
* Fix fliker icon
* Update metabox script
* Update Revolution Slider

= Version 2.3.9 =
* Fix some woocommerce variations issues with select2
* Fix radio issue for variations
* Fix call to action widget
* Fix for mqtranslate

= Version 2.3.8 =
* Tweek a print style
* Fix mobile nav link
* Add blog posts shortcode gen
* Fix product sidebar issue
* Add pre-layout for pagebuilder
* Add Select styles for desktop
* Add call to action widget
* Add class for your cart "dash"
* Fix variable select box for ipad
* Fix a common issue with category images for woocommerce

= Version 2.3.7 =
* Add Print styles
* Add contact page options
* Add border option to PageBuilder Row 

= Version 2.3.6 =
* Add Row Styles, Parallax backgrounds, Color backgrounds
* Add example page template
* Add Widget area to Header
* Add popover shortcode
* Add Multiple Addresses support for Google Maps Shortcode and Widget
* Add Auto-play option for portfolio slider
* Add even/odd css for accordion.
* Fix max width in youtube and Vimeo shortcode
* Update framework to work on platforms without WP_CONTENT_URL
* CSS fix for wp figure

= Version 2.3.5 =
* Password protection for portfolio.
* Carousel Script Update
* Remove some JS files from Redux
* Add Google Maps to Shortcode Generator
* Add Simple Math to contact form
* Add filter option to home page portfolio posts
* Add default for Posts Header
* Update Recent posts Carousel with order by options
* Update languages

= Version 2.3.4 =
* Update Icon Font.
* Add single post navigation.
* Add new social icons to virtue:social widget.
* Remove Custom Select, replace with Select2.
* Fix Vimeo Shortcode.
* Fix sticky header loading issue.
* Fix Firefox Caroufedsel Issue.
* Fix Z-index added Cart issue.
* Switch Pull-quote icon to retina icon.
* Switch flexslider arrow with retina icon.

= Version 2.3.3 =
* Add New Shortcode Generator Framework
* Fix issue with sticky header
* Fix Icon select in widgets
* Small css fixes

= Version 2.3.2 =
* Small Category Fix.
* Small Fix with theme options.
* Language file updates.

= Version 2.3.1 =
* CSS z-index sticky header fix
* Update options panel
* Add option for dropdown colors
* Updated woocommerce file
* Updated CustomSelect js
* Add basic styling to customizer
* Shortcodes in Custom Product tabs
* Link issue for Mobile
* Visual Improvements for Ipad
* Image Size Improvements

= Version 2.3.0 =
* Carousel Excerpt Fixes (Testimonial Carousel)
* Fix page scroll Issue with wootabs
* Update Spanish translation
* Update Italian translation

= Version 2.2.9 =
* Add smooth anchor scrolling
* Add option to move revolution slider above header
* Sticky Header for Mobile option for Header 3
* Add comment links
* Small CSS fixes
* Fix issue with sku.
* hfeed issue
* Image support in icon box shortcode
* Added dots and gradient divider lines 
* Small Excerpt fixes
* Fix page subtitle size
* Fix small jump issue with firefox
* Enable Category Descriptions

= Version 2.2.8 =
* Added Support for wp-retina plugin.
* Added Support for blog grid on home page and infinite scroll
* Added support for woocommerce badges plugin
* Updated spanish translation.
* Fixed Bug with custom woocommerce tabs
* Fixed bug on testimonial grid
* Fixed bug with Metaboxes and wordpress 3.9
* Fixed bug with firefox left click on products
* Update Revolution slider

= Version 2.2.7 =
* Added options for link targets with slides.
* Added lightbox for image carousels on posts.
* Fixed issues with new/window link.
* Update Breadcrumb issue
* Updated language files.
* Fixed issue with recent posts widget date.

= Version 2.2.6 =
* Added New Virtue Google Maps Widget
* Added New Features for Smooth Scroll
* Bug Fix Firefox search text.

= Version 2.2.5 =
* Update packaged version of revolution slider
* Add up to 3 Custom tabs for woocommerce!
* Add target option for topbar icons
* Bug fixes for shrink header
* Bug fixes for android
* Bug fix for page builder

= Version 2.2.4 =
* Add new Widget Info Boxes
* Add product arrow navigation
* Add product category carousel option. 
* Chrome bug Icon fix.
* Bug fix for product filter issue in dashboard. 
* Update language files (fix issue in french translation).
* Bug fixes for andriod

= Version 2.2.3 =
* Add Page Builder Support
* Add New Gallery Widget
* Add New Carousel Widget
* Add image carousel option to portfolio
* Add image carousel option to home page
* Improved Image Widget
* Improved Testimonial Widget
* Fix jumping of images in chrome browser
* Fix carousel issue on full post page
* Fix for products in tabs or accordions
* Fix for php 5.2 error
* Update Google Fonts
* Small CSS Improvements

= Version 2.2.2 =
* Fix for carousel on android
* Add filter call for qtranslate
* Fix for child theme trying to update
* Add fix for m4v videos
* Add fix for carousel slider on portfolio page

= Version 2.2.1 =
* Fix for carousel on andriod
* Fix for carousel slider
* Update language file
* Small fix for qtranslate menu description

= Version 2.2.0 =
* Add Update Notifier and API download - YAY
* Add Portfolio shortcodes
* Add Staff Shortcodes
* Add filters to default placement images
* Add support for mp4 videos
* Add link for banner
* Update google fonts to work on more server configurations
* Update button shortcode for target attribute
* Update woocommerce template
* Fix carousel on android
* Small Fix widget script
* Small change in isotope
* Small css fix for author image
* Small fix Custom carousel
* Make dynamic filter off by default

= Version 2.1.6 =
* Small Fix to menu css
* Isotope Fix
* Small update to icon menu
* Update language file

= Version 2.1.5 =
* Fix carousel Issue on iphones
* Nice Scroll Updated
* Fix ajax cart
* Isotope Updated
* Added Smart Resize

= Version 2.1.4 =
 * Small Fix for woocommerce filter
 * Small Fix for translation 
 * Small Fix for qtranslate
 * Fix Carousel Issue on iphones
 * Add shortcode for google map
 * Add Sticky Header option
 * Add two new Header Styles

= Version 2.1.3 =
 * Small Fix with Image Captions
 * Cart Widget fix
 * Remove woocommerce template files.

= Version 2.1.2 =
 * Small Fix for Carousel

= Version 2.1.1 =
 * Add Carousel Slider to home and portfolio posts
 * Turn SEO options off by default
 * Add default sidebar for products

= Version 2.1.0 =
 * Fix Androd browser issue with carousel
 * Update woocommerce files

= Version 2.0.9.9 =
 * Small Fix for box layout
 * Small Fix for qtranslate
 * Small Fix for gallery captions
 * Add wpml-config.xml file
 * Change language files folder to languages
 * Add option for sold text
 * Add option for sale text
 * Fix products with variations for woocommerce 2.1

= Version 2.0.9.7 =
 * Small Fix with Gallery Carousel Captions
 * Update css for better upgrade from versions below 1.7.4
 * Update Spanish language files
 * Force Portfolio Type Pages to order by menu order.
 * Add options for portfolio navigation arrows to stay within portfolio-type.
 * Add meta box for portfolio posts to override theme options portfolio grid page.
 * Add options to portfolio bottom carousel.
 * Clean Up some files.

= Version 2.0.9.6 =
 * Fix Icon Issue in theme options

= Version 2.0.9.5 =
 * Fix Icon Issue in theme options
 * update language file.

= Version 2.0.9 =
 * Add Support for qtranslate
 * Minor css Fix
 * Fix portfolio link issue
 * Update woocommerce template files, add support for 2.1
 * Fix issue with ajax filter in products
 * Update Theme options for speed. 


= Version 2.0.8 =
 * Fix some small styling with product quantity.
 * Fix all text in filter.
 * Fix for icon boxes in sidebar.
 * Add French Language files

= Version 2.0.7 =
 * Add shortcode for slider of posts.

= Version 2.0.6 =
 * Fix Virtue Toolkit issue.
 * Updated Flexslider 2.2.2
 * Add Italian Language

= Version 2.0.5 =
 * Fix Gallery captions
 * Fix figure styles
 * Fix product image style

= Version 2.0.4 =
 * Fix Sidebar Issue on shop page.
 * Clean up mobile menu for firefox.
 * Add Gallery Carousel option.
 * Add Gallery Caption option.
 * Add Gallery Slider option.
 * Clean up some product styles.

= Version 2.0.3 =
 * Fix Author Box.
 * Fix typography not loading all styles.
 * Fix media queries in ie8
 * 8 Fix contact form 
 * Some prep for woocommerce 2.1

= Version 2.0.2 =
 * Make it possible to have two different columns styles on one page of products.
 * Add options to the home page for portfolio height.
 * Fix product image res.
 * Add option for sold tag with products out of stock.

= Version 2.0.1 =
 * Add support for 1 column image menu (sidebar).
 * Add option for sidebar on category pages.
 * Fix Category Grid Issue
 * Fix product-category css issue
 * Various Small Fixes.

= Version 2.0.0 =
 * Fix Blog Grid Issue
 * Fix Rating issue on category pages
 * Add Option for infinite Scroll on Blog Posts
 * Add shortcode for custom image menu
 * Site Default for Blog Posts
 * Fix Language Issue with theme options

= Version 1.9.9.9 =
 * Update Theme Options, Various Speed improvements
 * Add warning for Virtue Toolkit Plugin
 * Change shortcode gen to ajax.
 * Add shortcode to testimonials
 * Clean up css for cart in firefox
 * Add Custom Carousel Support
 * Add support for infinite scroll

= Version 1.9.9.6 =
 * Not ready for 2.0 launch just yet.
 * Add Permalink option for portfolio for better translation.
 * Add some small styling for qTranslate
 * Fix blog_post shortcode to default to order by date

= Version 1.9.9.5 =
 * Not ready for 2.0 launch just yet.
 * Allow for jetpack comments
 * Add more animations 
 * Add image flip for products
 * Added Support for Yith Ajax Plugin. 
 * Add radio button options for products
 * Add shortcodes for products, posts, portfolio items.

= Version 1.9.9 =
* Fix edit image issue
* Add svn to framework.php
* Fix related products issue
* Add default for product sidebar
* Add a couple shortcodes

= Version 1.9.8 =
* Fix small animation conflicts

= Version 1.9.7 =
* Fix small animation conflicts

= Version 1.9.6 =
* Fix small animation conflicts

= Version 1.9.6 =
* Update Theme Options panel (speed improvement) (fix url in slides)
* Started Animation fade in (to be finished by version 2)

= Version 1.9.5 =
* Fix testimonial widget issue
* Fix carousel jump on mobile
* Fix blog issue when no feature image
* Add option for one column of blog posts on home page
* Update Alt text on portfolio images
* Fix issue with shortcode on feature page
* Fix issue with woocommerce shortcodes

= Version 1.9.4 =
* Fix Gallery Issue
* Add iconbox Shortcode
* Add Cyclone Slider
* Product Category Metabox
* Add icons for woocommerce
* Ajax cart refresh
* Add secondary menu item width option
* Add Comments to portfolio items
* Add Revslider and Cyclone slider to portfolio items
* Add Default for author box
* Fix Post similar carousel 


= Version 1.9.3 =
* Fix Shop Column Issue

= Version 1.9.2 =
* Update how many carousels items can be chosen
* Updated upsell and cross sell output

= Version 1.9.1 =
* Update nav background option
* Update product layout selection

= Version 1.9.0 =
* Upgrade Framework to bootstrap 3! YAY!
* Add columns options for carousels
* Add column options for products
* Add column options to icon menu, image menu.
* Fix issues with portfolio order when data selected
* Add options for video width
* Add carousel speed options and swipe count options
* Add styles for wp calendar
* Add options for archive and category layouts
* Add Search results sidebar options
* Add New Layout options for Products
* Added new product category layout options

= Version 1.8.3 =
* Fix error with contact page

= Version 1.8.2 =
* Fix error

= Version 1.8.1 =
* Fix Issue on frontpage.php
* Fix Issue with contact form
* Add styling for contact form 7
* Update print css styles
* Fix widget issue when translating
* Added option for a widget in the home page


= Version 1.8.0 =
* Fix typography issue error
* add import old options tab
* add option for portfolio amount
* added option for product count and portfolio count
* added styles for product search
* added new layout for search results

= Version 1.7.9 =
* Fix for Subversion
* Change theme options location
* Fix for certain people having issue with server not loading page


= Version 1.7.8 =
* Font Fix in theme options

= Version 1.7.7 =
* Speed in theme options update 

= Version 1.7.6 =
* Add More Icons! 
* Change column default to shortcodes
* Fix woocommerce widget and results count styling
* Fix issue with custom css box
* Fix issue category filter

= Version 1.7.5 =
* New Theme Options panel
* Add options to disable virtue image sizing to product images
* Fix loading feature with carousel.
* Add mobile filter options.
* Fix breadcrumb issues.
* Remove Retina.js from theme.
* Move to Mobile Detect
* Add shortcode for info box
* Add description to icon menu
* Add latest post slider option

= Version 1.7.4 =
* Add fix for product images

= Version 1.7.3 =
* Add fix for related products with sidebar

= Version 1.7.2 =
* Antispambot to vcard widget
* Add option to disable image resize for products
* Fix tab issue with empty tabs
* Fix light box Caption issue
* Make gallery link title and image alt different for better SEO

= Version 1.7.1 =
* Added Tab Order Options
* Added Sidebar on Product Page Option
* Updated Contact Form
* Fixed Some Language Issues updated plural texts.
* Added option to change "by" text.
* Added Option to rename product video.
* Added option to change gallery format per post
* Added option for full width slider on shop page
* Updated Shortcode Buttons to work on all servers.

= Version 1.7.0 =
* Updated some css for IE8
* Add classed for footer columns
* Switched lightbox plugin.
* Added two new portfolio Options

= Version 1.6.9 =
* Updated Language Settings to allow for all to be changed in admin
* Updated logo layout options to have half

= Version 1.6.8 =
* Updated Language Settings to allow for product page tabs and related products
* Updated Mobile slider
* Added opt in for retina.js
* Updated language issue for topbar widget.

= Version 1.6.7 =
* Update Menu to allow 5 levels
* Update Feature Template with lightbox options.

= Version 1.6.6 =
* Update AquaResizer
* Add Page Template Blog Grid
* Add Category Page Subtitle
* Fix Pretty Photo Styling
* Add to options: turning off Virtue Gallery
* Add to options: Virtue Gallery Masonry
* Updated Styles in Admin Theme Options
* Updates tab for Mobile

= Version 1.6.5 =
* Update Image Menu and Icon Menu
* Added Custom Carousel
* Fixed Issue with testimonials widget
* Issue with revslider spacing
* Grid fix
* Added to Language Changes
* Added options for icon background and text color

= Version 1.6.4 =
* Update Admin CSS issue

= Version 1.6.3 =
* Added stumbleupon and rss to social widget.
* Added Nice Scroll to options
* Fixed issue with portfolio slider
* Fixed issue on home page with 8 image menu items
* Updated Styles in Theme Settings


= Version 1.6.2 =
* Updated language files

= Version 1.6.1 =
* Added Custom CSS to header, speed improvement.
* Added more menu options for hover and active states
* Added option to disable image border
* Added option to hide post date
* Added option to hide posted in tag
* Added option to hide comment icon
* Changes class for products
* Improved theme for language translation.
* Added more options to testimonial widget
* Updated css for testimonial widget
* Now using different javascript for woocommerce variations (fixes variation issues)


= Version 1.6.0 =
* Added new Skins "forest, sky, blush"
* Added prettyPhoto, removed lightbox 2
* added Gmap3, removed gmap
* Added timestamp to custom css version
* Added fix for image menu with 8 items


= Version 1.5.9 =
* Fix issue with footer translation.
* Fix issue with icons disappearing in theme options when translated
* Fix issue with excerpts not showing shortcodes 
* Fix issue with testimonials box not being sharp on retina screens
* Added order-by options on portfolio page and home page
* Added option to show portfolio items in columns of 5 items
* Added option to limit page width
* Updated Revolution Slider

= Version: 1.5.8 =
* Fix issue with footer and simply instagram plugin

= Version: 1.5.7 =
* Fix breadcrumb Issue on blog post

= Version: 1.5.6 =

* Update how carousel gallery looks on mobile
* Added option for changing "read more" text
* Added option for changing "posted in" text
* Updated Widget CSS
* Added Breadcrumbs
* Added option to only show icon for mobile menu

= Version: 1.5.5 =

* Added option for full blog on home page
* Added fix for author box
* Added fix for mobile and center logo 


= Version: 1.5.4 =

* Added new Mobile Menu
* Added mobile menu background and font options
* Updated how google fonts called for https
* Updated how google maps api called for https

= Version: 1.5.3 =

* Added options for filter on product category pages

= Version: 1.5.2 =

* Added Support for sidebar on home page
* Added Support for subcategory products

= Version: 1.5.1 =

* Fixed css for variation sale products
* Fixed issue with primary color 30

= Version: 1.5.0 =

* Add Portfolio image size options
* Add gallery metabox
* Add support for child themes
* Add support to turn off SEO
* Add third Layout for Portfolio
* Added 250 Icons, now over 400!
* Add support for 16 portfolio options on home page
* Switched tool tip for home blog posts
* Add linkedin to social icon widget
* Added full width blog posts
* Added full width blog pages
* Fixed Issue with top bar icon links
* Added a new skin: pebble
* Added Wordpress Gallery sizes to 7
* Added Single Column Layout for Shop
* Added option to hide add to cart till mouse hover

= Version: 1.4.3 =

* Fixed Rev Slider Error


= Version: 1.4.2 =

* Updated CSS
* Changed add lightbox function
* Add Tagline font options
* Add Gray font options

= Version: 1.4.1 =

* Updated Revolution Slider Error
* Added Child Theme to download option
* Added max width and height to sliders

= Version: 1.4.0 =

* Updated CSS
* Added Child Theme Ability
* Added Topbar options, and widget
* Add dropdown ability in top menu

= Version: 1.3.9 =

* Updated CSS to better deal with feature image page
* Added option to hide closed comments notice.

= Version: 1.3.8 =

* Updated CSS to hide secondary menu on small screens
* Fixed Issue with Rev Slider on Feature pages

= Version: 1.3.5 =

* Changed how jQuery called in font end.
* Removed a series of things from cleanup.php
* Removed update notification for the time being.
* Adjusted how captions work when flex slider is set to slide
* Added option to adjust topbar color.
* Fixed issue with feature pages not using custom sidebar
* Updated Testimonial Widget
* Fixed Issue with topbar not hiding
* Updated portfolio next to follow menu order.
* Center logo option.
* Add banner option.

