<div class="sliderclass cyclone_shop_slider">
<?php global $virtue_premium; echo do_shortcode( $virtue_premium['shop_cyclone_slider'] ); ?>
</div><!--sliderclass-->