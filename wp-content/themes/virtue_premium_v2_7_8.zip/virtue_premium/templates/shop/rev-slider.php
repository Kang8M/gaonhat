<div class="sliderclass">
<?php global $virtue_premium; putRevSlider( $virtue_premium['shop_rev_slider'] ); ?>
</div><!--sliderclass-->