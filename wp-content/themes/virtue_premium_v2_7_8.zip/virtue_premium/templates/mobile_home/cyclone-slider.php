<div class="sliderclass cyclone_mhome_slider">
<?php global $virtue_premium; echo do_shortcode( $virtue_premium['mobile_cyclone_slider'] ); ?>
</div><!--sliderclass-->