<div class="sliderclass revslider_home_hidetop">
<?php global $virtue_premium; putRevSlider( $virtue_premium['mobile_rev_slider'] ); ?>
</div><!--sliderclass-->