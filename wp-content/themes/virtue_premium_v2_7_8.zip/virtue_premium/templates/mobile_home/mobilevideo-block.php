<div class="sliderclass">
<div id="imageslider" class="container">
			<div class="videofit">
                  <?php global $virtue_premium; echo $virtue_premium['mobile_video_embed'];?>
                  </div>
        </div><!--Container-->
</div><!--feat-->