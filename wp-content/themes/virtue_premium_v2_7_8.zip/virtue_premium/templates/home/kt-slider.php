<div class="sliderclass ktslider_home_hidetop">
<?php global $virtue_premium; echo do_shortcode( '[kadence_slider id="'.$virtue_premium['kt_slider'].'"]' ); ?>
</div><!--sliderclass-->