<div class="sliderclass cyclone_home_slider">
<?php global $virtue_premium;  echo do_shortcode( $virtue_premium['home_cyclone_slider'] ); ?>
</div><!--sliderclass-->