<div class="sliderclass revslider_home_hidetop">
<?php global $virtue_premium;  
	if( function_exists('putRevSlider') ) {
		putRevSlider( $virtue_premium['rev_slider'] ); 
	} ?>
</div><!--sliderclass-->